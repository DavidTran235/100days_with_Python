from turtle import Turtle, Screen
import random

screen = Screen()
screen.setup(width=500, height=400)

# ++++++++++++
##Drawing a Etch-a-Sketch
# def Forwards():
#     return tim.fd(10)
# def Backwards():
#     return tim.bk(10)
# def Counter_Clockwise():
#     return tim.left(5)
# def Clockwise():
#     return tim.right(5)
# def Clear_drawing():
#     return tim.reset()
#

# screen.listen()
#
# screen.onkey(Forwards, "w")
# screen.onkey(Backwards, "s")
# screen.onkey(Counter_Clockwise, "a")
# screen.onkey(Clockwise, "d")
# screen.onkey(Clear_drawing, "c")
# ==========================
user_bet = screen.textinput(title="Make your bet", prompt="Which turtle will win the race? Enter a color: \nRed, Purple,"
                                                          " Blue, Yellow, Green, Violet").lower()
colours = ["red", "purple", "blue", "yellow", "green", "violet"]
k = 0
all_turtles = []
#Drawing a Start line
def start():
    start_line = Turtle()
    start_line.pensize(1)
    start_line.hideturtle()
    start_line.pu()
    start_line.setpos(x=-210, y=180)
    start_line.pd()
    start_line.setheading(270)
    start_line.fd(360)

def finish():
    finish_line = Turtle()
    finish_line.pensize(1)
    finish_line.hideturtle()
    finish_line.pu()
    finish_line.setpos(x=220, y=180)
    finish_line.pd()
    finish_line.setheading(270)
    finish_line.fd(360)


start()

for i in range(len(colours)):
    new_turtle = Turtle(shape="turtle")
    new_turtle.pu()
    new_turtle.speed(2.5)
    new_turtle.color(colours[i])
    new_turtle.goto(x=-230, y=-120 + k)
    k += 50
    all_turtles.append(new_turtle)

finish()

def check_win():
    if win_turtle_color == user_bet:
        print("You are the winner!")
    else:
        print(f"The {win_turtle_color} turtle win the race. You lose!")


if user_bet:
    is_race_on = True

while is_race_on:
    for turtle in all_turtles:
        random_distance = random.randint(0, 10)
        turtle.fd(random_distance)
        if turtle.xcor() > 220:
            win_turtle_color = turtle.pencolor()
            is_race_on = False

check_win()

screen.exitonclick()
