
from turtle import Turtle, Screen
import turtle as t
import random

tim = t.Turtle()
t.colormode(255)
tim.shape("turtle")
tim.speed("fastest")
# colours = ["CornflowerBlue", "DarkOrchid", "IndianRed", "DeepSkyBlue", "LightSeaGreen", "wheat", "SlateGray", "SeaGreen"]
directions = [0, 90, 180, 270, 360]
# tim.pensize(8)


def random_color(): #random RGB colours
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    r_color = (r, g, b)
    return r_color


# for i in range(4):# Draw a square
#     tim.forward(100)
#     tim.right(90)

# ---------------------------------
# def dashed_line(tim, length, n):
#     for i in range(length - 1):
#         tim.forward(length / n)
#         tim.penup() # No draw
#         tim.forward(length / n)
#         tim.pendown() # Draw
#         tim.forward(length / n)
#
#
# for i in range(4):
#     dashed_line(tim, 20, 5)
#     tim.right(90)
# ---------------------------
# #drawing different shape
# def draw_shape(edge):
#     for i in range(edge):
#         tim.forward(75)
#         tim.right(360 / edge)
#
#
# for edge in range(3, 11):
#     tim.color(random.choice(colours))
#     draw_shape(edge)
# tim.forward(75)
#
# ==========================
#Drawing a random walk
# for _ in range(300):
#     tim.color(random_color())
#     tim.forward(20)
#     tim.setheading(random.choice(directions))
# ==================================
#Drawing circle circle
r= 100

def draw_spirograph(size_of_gap):
    for _ in range(int(360/size_of_gap)):
        tim.color(random_color())
        tim.circle(r)
        tim.setheading(tim.heading() + size_of_gap)

draw_spirograph(5)

screen = Screen()
screen.exitonclick()
