#import colorgram
import random
import turtle as t
#TODO Create an extract color list of RGB color from a picture
#
# color_frame = colorgram.extract("image.jpg", 30)
# rgb_colors = []
# for i in range(len(color_frame)):
#     rgb = color_frame[i].rgb
#     rgb_colors.append((rgb.r, rgb.g, rgb.b))
# print(rgb_colors)

color_list = [(132, 166, 205), (221, 148, 106), (32, 42, 61), (199, 135, 148), (166, 58, 48), (141, 184, 162), (39, 105, 157), (237, 212, 90), (150, 59, 66), (216, 82, 71), (168, 29, 33), (235, 165, 157), (51, 111, 90), (35, 61, 55), (156, 33, 31), (17, 97, 71), (52, 44, 49), (230, 161, 166), (170, 188, 221), (57, 51, 48), (184, 103, 113), (32, 60, 109), (105, 126, 159), (175, 200, 188), (34, 151, 210), (65, 66, 56)]
tim = t.Turtle()
tim.speed(0.5)
t.colormode(255)
tim.pu()
tim.hideturtle()

def reconstruction_position():
    tim.setheading(225)
    tim.fd(300)
    tim.setheading(0)

def tp(): #teleport
    tim.setheading(90)
    tim.fd(50)
    tim.setheading(180)
    tim.fd(500)
    tim.setheading(0)

def drawing():
    for _ in range(10):
        tim.dot(20, random.choice(color_list)) #need to change the range of the color to 255 by colormode
        tim.fd(50)

reconstruction_position()
for time in range(10):
    drawing()
    tp()

screen = t.Screen()
screen.exitonclick()
