from turtle import Turtle
ALIGNMENT = "center"
FONT = ("Courier", 20, "bold")


class Scoreboard(Turtle):

    def __init__(self):
        super().__init__()
        self.score = 0
        self.color("white")
        self.pu()
        self.hideturtle()
        self.goto(0, 260)
        self.updated_scoreboard()

    def updated_scoreboard(self):
        self.write(f"Score: {self.score}", align=ALIGNMENT, font=FONT)

    def score_up(self):
        self.score += 1
        self.clear()
        self.updated_scoreboard()

    def game_over(self):
        self.color("white")
        self.hideturtle()
        self.pu()
        self.goto(0, 0)
        self.write("GAME OVER", align=ALIGNMENT, font=FONT)

